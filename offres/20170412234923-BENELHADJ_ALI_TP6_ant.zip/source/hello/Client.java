package hello; 
import javax.naming.*; 
 
public class Client { 
 
 public static void main(String[] args) throws Exception { 
 
 //JBoss default remote jndi: <ejb-name>/remote 
 
 InitialContext ctx = new InitialContext(); 
 
 Object obj = ctx.lookup("HelloBean/remote");
 
 System.out.println("lookup returned " + obj); 
 
 HelloRemote hello = (HelloRemote) obj; 
 
 String s = hello.echo("Hello EJB3"); 
 
 System.out.println(hello + " echo returned " + s); 
 } 
}